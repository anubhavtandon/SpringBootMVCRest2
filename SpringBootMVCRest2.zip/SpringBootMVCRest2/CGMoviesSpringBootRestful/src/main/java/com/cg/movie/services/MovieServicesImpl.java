package com.cg.movie.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Song;
import com.cg.movie.daoservices.MovieDAO;
import com.cg.movie.daoservices.SongDAO;
import com.cg.movie.exceptions.MovieDetailsNotFoundException;
import com.cg.movie.exceptions.SongDetailsNotFoundException;

@Component
public class MovieServicesImpl implements MovieServices{
	@Autowired
	MovieDAO movieDao;
	@Autowired
	SongDAO songDao;
	@Override
	public Movie acceptMovieDetails(Movie movie) {
		return movieDao.save(movie);
	}
	@Override
	public Movie getMovieDetails(int movieId) throws MovieDetailsNotFoundException {
		return movieDao.findById(movieId).orElseThrow(()->new MovieDetailsNotFoundException());
	}

	@Override
	public Song acceptSongDetails(Song song) {
		return songDao.save(song);
	}

	@Override
	public Song getSongDetails(int songId) throws SongDetailsNotFoundException {
		return songDao.findById(songId).orElseThrow(()->new SongDetailsNotFoundException());
	}

	@Override
	public List<Song> getAllSongDetails(int movieId) {
		return songDao.findAllSongs(movieId);
	}

}
