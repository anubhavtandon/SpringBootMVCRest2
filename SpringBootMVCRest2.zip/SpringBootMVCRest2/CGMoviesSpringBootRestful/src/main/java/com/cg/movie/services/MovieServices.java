package com.cg.movie.services;

import java.util.List;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Song;
import com.cg.movie.exceptions.MovieDetailsNotFoundException;
import com.cg.movie.exceptions.SongDetailsNotFoundException;
public interface MovieServices {
	Movie acceptMovieDetails(Movie movie);
	Movie getMovieDetails(int movieId) throws MovieDetailsNotFoundException ;
	Song acceptSongDetails(Song song);
	Song getSongDetails(int songId) throws SongDetailsNotFoundException ;
	List<Song> getAllSongDetails(int movieId);
}
